https://sourceforge.net/p/tribalcreature/wiki/Home/
[This is the homepage, if in doubt]

This and a bunch of other stuff downloadable from the following and their subfolders:

https://sourceforge.net/projects/tribalcreature/
https://sourceforge.net/projects/tribalcreature/files/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/Zarakite%20American%20English/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/Ideas/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/Book%20Of%20Faces/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/attachments/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/Common%20Sky%20Boy%20Names/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/Proto/assets/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/Proto/music/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/Proto/Films/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/Proto/3D%20Models/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/Proto/Downloads/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/Proto/grocery%20lists/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/Proto/Police/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/Proto/Book_Of_Shadows/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/chosen/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/chosen/056_Tony_TigerStone/
https://sourceforge.net/projects/tribalcreature/files/White%20Rain%20and%20Recruitment%20Program/Proto/Posts%20to%20Irrlicht%20Forum/

https://sourceforge.net/projects/white-rain/
https://sourceforge.net/projects/white-rain/files/
https://sourceforge.net/projects/white-rain/files/David_A_Reeves_287_74_8719/Zarakite_American_English/
https://sourceforge.net/projects/white-rain/files/Ideas/
https://sourceforge.net/projects/white-rain/files/Book%20Of%20Faces/
https://sourceforge.net/projects/white-rain/files/Recruitment%20Program/attachments/
https://sourceforge.net/projects/white-rain/files/Recruitment%20Program/sky%20boys/Common%20Sky%20Boy%20Names/
https://sourceforge.net/projects/white-rain/files/David_A_Reeves_September_25_1978/notes/
https://sourceforge.net/projects/white-rain/files/David_A_Reeves_287_74_8719/notes/
https://sourceforge.net/projects/white-rain/files/David_A_Reeves_September_25_1978/assets/
https://sourceforge.net/projects/white-rain/files/Zare/assets/
https://sourceforge.net/projects/white-rain/files/David_A_Reeves_287_74_8719/assets/
https://sourceforge.net/projects/white-rain/files/Proto/assets/
https://sourceforge.net/projects/white-rain/files/Cuut/Assets/
https://sourceforge.net/projects/white-rain/files/Cuut/grocery%20lists/
https://sourceforge.net/projects/white-rain/files/David_A_Reeves_287_74_8719/Movies/
https://sourceforge.net/projects/white-rain/files/Destructavator_JS/
https://sourceforge.net/projects/white-rain/files/Pizza_00/
https://sourceforge.net/projects/white-rain/files/Pizza_01/
https://sourceforge.net/projects/white-rain/files/Pizza_02/
https://sourceforge.net/projects/white-rain/files/Pizza_03/
https://sourceforge.net/projects/white-rain/files/Food%20Tests/
https://sourceforge.net/projects/white-rain/files/Cuut/Posts%20to%20Irrlicht%20Forum/

https://sourceforge.net/projects/scorchcrafter/
https://sourceforge.net/projects/scorchcrafter/files/
https://sourceforge.net/projects/scorchcrafter/files/Sky%20boy%20stuff/
https://sourceforge.net/projects/scorchcrafter/files/Sky%20boy%20stuff/Sky_Boy_and_Human_American_English/
https://sourceforge.net/projects/scorchcrafter/files/Sky%20boy%20stuff/Ideas/
https://sourceforge.net/projects/scorchcrafter/files/Sky%20boy%20stuff/Book%20Of%20Faces/
https://sourceforge.net/projects/scorchcrafter/files/Sky%20boy%20stuff/attachments/
https://sourceforge.net/projects/scorchcrafter/files/Sky%20boy%20stuff/Common%20Sky%20Boy%20Names/
https://sourceforge.net/projects/scorchcrafter/files/Sky%20boy%20stuff/Dave/assets/
https://sourceforge.net/projects/scorchcrafter/files/Sky%20boy%20stuff/Dave/Proto%20College%20Tri-C/Speech%201010/Videos_with_Original_For_Almandine_Boys_In_Background_Steve_Schlaf/
https://sourceforge.net/projects/scorchcrafter/files/Sky%20boy%20stuff/Dave/Posts%20to%20Irrlicht%20Forum/

http://irrlicht.sourceforge.net/forum/viewtopic.php?f=6&t=48321

Much talk from this forum, one of 1908 posts, including intellectual talks about - theoretical alien speicies, how a hypothetical sentient species evolves on various worlds and resulting characterisitcs, astronomy, serious-minded UFOs and exosolar life that has intelligent and educated non-conspiracy-theory scientific discussions as well as silly and shortsighted ignorant ultra-religious 'quick-and-snappy' paranoid rejection of alien life combined with tin foil hat psychotic talk and other discussions inbetween such, hard sci-fi and soft-sci-fi, intelligent talk as well as Chris-Sandusky-style-logic and what a 'wordoid' is, what a 'freshy' is [slang term, used in Antarctic historical species colonies where such live and such populations also go to [public] school and have local banks and convenience stores] etc, possible references to why some Antarctic human towns that have scientists seem to have an intelligent and clear-headed and non-infected understanding of global climate change and how dangerous funny-looking colored clouds in the sky are yet also 'mail-order' very large supplies of condoms for the six-month winters [believe it or not, there IS a casual, logical relationship between these two concepts, amid crackpot humor], and other stuff... -:
https://ufoai.org/forum/index.php/topic,7642.msg58951.html#msg58951

https://www.youtube.com/channel/UC2xfCv4RfbLfOn0pCiVQd5g
https://www.youtube.com/user/Destructavator/about

https://www.youtube.com/user/Destructavator/videos
https://www.youtube.com/user/Destructavator/playlists

https://www.linkedin.com/in/david-reeves-21430712b/
OLD [I don't log in to this one anymore, though information here is still honest, and still valid]:
https://www.linkedin.com/in/david-reeves-b4557184/

https://drive.google.com/drive/folders/1Jv9HGYYi_Yhb4G-vhUQIj34wuFtl8yi_?usp=sharing
https://drive.google.com/open?id=1Jv9HGYYi_Yhb4G-vhUQIj34wuFtl8yi_

https://www.dailymotion.com/dm_eb76aaf50e9650432fd5d6e8fe7cdd16

https://www.facebook.com/profile.php?id=100042638266991

EMAIL:
zare166@yahoo.com
davereevesguitar12@gmail.com
davereevesguitar12@protonmail.ch
blahblahblex@gmx.us

Hypothetical #0000:
	A human being of a species as they were in the 1800s jumps out of a plane and forgets to put on a parachute first.  He has a serious and long drop before he hits the ground and is about to die momentarily and he knows that his death is probably going to happen and is about to happen shortly.  He can see the ground rushing towards him.  No one else is nearby who is also skydiving and no one else fell out of or jumped out of the aircraft he came out of.  If he wants to think up an idea to save his life, he can't.  He would panic if he were like any normal human being from the 1800s with any common intellect and any normal personality.  Whether he is smart and a real bookwork or dull-witted, socially smart and socially apt or extremely gullible and socially inept, irregardless if he were to think to himself 'How am I going to survive?  I want to think up an idea so I survive this, so I don't die, and I somehow make it.  I of course need to think up something realistic and I need to think of it very quickly and within a minute or two before I hit the ground with an impact that literally kills me.  How do I avoid death?' rephrased in any combination of words and-or grammar [most type of men in this situation as well as myself wouldn't think that much in any mentally pronounced language, or anything close to that much for that matter as it would take way too long of course and be a deadly and illogical and strategically bad waste of time and a bad idea to take that long and be extraneous like that] he isn't going to come up with any answer better than some phrasing or wording of 'The answer is simple.  I don't.' and that is simply real life.  Being realistic is what he is stuck with here, and as part of it he doesn't survive and doesn't have any solution to avoid death.  He doesn't have any way out of this situation where he avoids death and there isn't anything he can think up or plan or ponder or contemplate to change this and he knows it.  Praying to some god to survive of course isn't going to save him either and he knows it although he might do that anyways.  He might spend the last moments of his life thinking about the life he had and what he accomplished in it and might judge himself and whether or not he thinks he had a good life versus an empty life where he had unfulfilled dreams and goals and didn't get to even try to make them happen.  After all there is no point in trying to think up any so-called 'solution' or 'plan' to save himself as he's fully aware that the only answer is more or less 'How do I survive this?  Simple, I don't.' as a concept that is his only answer.  If he has fond memories of things he did and enjoyed he might think of those and give himself a few last moments of pleasure from them.  At the very least this would do something to counteract at least some of the stress and panic he is certainly feeling.  He would be inhuman as well as weird to not be in a panic and completely freaking out.  In fact some men of his potential type in his position would pass out.  Anger might also happen and come from having a combination of having an unfulfilled life as well as facing the unbeatable and undeniable and unrefutable fact that he is going to die and there is no way around it and there is nothing he can do about it or out-think no matter what and he has to accept this and there is no point blaming anyone for the position and situation he is in.  This includes if someone else really is at fault [for example, if someone murdered him by pushing him or throwing him out of the plane by surprise].  If someone else is at fault for his imminent death he may be angry although he might give himself at least some peace/pleasure that counteracts this anger with an understanding that whoever he blames might be caught and not get away with his death and perhaps murder although he would have to be realistic about this of course as well as die without knowing if he would get justice after his death.  If someone were sneaky and tricky and clever about killing him then he probably isn't going to get justice or anyone to avenge him or hold his murderer[s] responsible and he knows it as he has to be realistic and being unrealistic or out-of-touch with how real life works doesn't work of course.
	This goes to show that sometimes there isn't a solution or answer to a problem and that's simply how it is.  Meditating or thinking won't work of course, and as I just said there isn't a solution or answer and that is simply what is.  Having any sort of intellect including a rare and-or superintelligent intellect isn't going to work and won't provide any answer or solution of course as once again there is NOT any answer or solution and that simply is the ONLY answer.  Being alseep or ignorant isn't going to help either and also won't prevent death and, guess what?  It won't save you if you're in this situation and it will NOT give you any way out or solution or answer to this death-trap of a situation and that is simply what you have to accept and that is simply the case.  Zarakite values agree and always will and would never disagree.  Not even after literally several thousand years go by along with plenty of thinking and learning and other ideas over that time.  There is no way that salt or guides that I would want would ever disagree either.  Having to repeat certain common sense facts of how real life works in many repetitive sentences like what I did here normally would be INSANE but some of the bad and hostile and infected guides needed it and they are never going to be guides that I would want or would have wanted or would accept.  Zarakite values and also any salt and any guides I would want would always agree with that and never disagree.  I am fully convinced of this and I think that guides and salt and various pleasures that I would want would agree and believe the same and not otherwise.
	Any immortal of planet Earth should agree with this and I can't imagine or believe otherwise.  Planet Earth would agree with that entire sentence and all of this entire set of concepts start-to-finish with all paragraphs and sentences included with complete invariably consistency.  Destiny and real life in this universe and many others as well I'm sure would also agree if they are being honest and lacking deception and also lacking evil.
	'Nuffs said.

Hypothetical #0001:
	2019-12-08  01:27  An archaic human being of a species as they were in the year 1990 CE planet Earth is driving a car then abruptly starts to wonder for a brief split second where he might have left his keys as well as whether or not he has his keys with him.  His keys include the keys to his home and his car and his life.  This is a minor distraction that really shouldn't happen, and if it occurs then something weird an unusual is going on but it shouldn't last long.  I've had this happen before when driving my Toyota Corolla I used to have and I was surprised at why it happened and where such plastic weird uncertainty was coming from and why it was pushed into my head.  It never felt natural or normal and clearly wasn't from my head or my thinking.  It was easy to set aside and ignore and lay to rest though with basic common sense and logic.  After all, if I am in this position and doing the same thing the man is doing, I am not his kind but I can think to myself [or rather whomeever or whatever was thinking the unnatural thoughts of THIERS and NOT MINE] 'Well gosh, if I am driving my car the engine is turned on which means I have to have the keys in the ignition, so it's not like I don't know where my keys are, as I use a key to put in the ignition and turn on the car and drive it and I don't know how to be a car theif and I don't do any weirdo-freak psychic thing like "the force" from Star Wars or anything to drive the car.' which pretty much settles the issue right then and there with no reason to come back.  Needless to say this one's a no-brainer if you look at the basic common sense and logic involved.  If I had a passenger sitting next to me sitting in the passenger seat and they asked 'Hey you didn't forget the keys, right?' I'd stare at them and maybe gesture towards under the steering wheel and mention something along the lines of 'Well I'm driving the car' and if they continued to stare at me blankly and were slow on the uptake and didn't space out like this too often and make me lose patience I guess I'd add 'I have to have the keys to drive the car'.  If if gets this far this is sort of rare, as most people I would think would not ask me something too often about the keys in the first place but if they did anyways the first thing I would say usually does the trick.  If it comes to having to mention the second thing you're probably talking about a co-worker and not a friend.  Logic.  If they puil shit like this all the damn time then you're looking at me being a guy who had to take his turn carpooling with this feather-head and being stuck with him for the morning.  Most human beings of the type mentioned in this hypothetical arn't quite that bad though.  Look, I've had literally ZERO first-hand actual connection points of this type of example scenario but I'm pretty sure as an intuitive guess that I'm right about this even though I've never actually lived through and experinced this situation or one close to it.  Don't get me wrong, to be honest I have to admit there's no established pretense for it for anything I've lived through or witnessed first-hand but I'm farily confident this is real life.  'Nuffs said.

Hypothetical #0002:
	2019-12-08  01:27  Steve Schlaf was always more socially intelligent than I've been.  When I met him he was more grown up than I was and I was socially inept by comparison and clueless while he was clever and lacking gullibility unlike myself who was clueless and unknowing compared to him.  This I witnessed first-hand.  I lived through and remember and witnessed first-hand direct connection points of this and so did he.  And then to be fair we have the species to species stuff and 'terrible two-hundreds' talk with teams and guides and how he drove his own car and was 'no longer a teenager' going from 19 to 20 and twenty is not in the teens on a number line stuff.  Anyways, he was socially smart and light-years ahead of me and I was trailing behind and nowhere near as clever as him.  He also taught me a few words and how to talk better to learn more so I would one day catch up with human beings.  An example is how things hypothetically would suck.  Um I guess we would have to get back to each other on that.

Hypothetical #0003:
	2019-12-10  18:35  When someone lacks credibility and wants to re-establish whether or not others should trust them, they can temporarily voluntarily step out and make themselves absent, and come back later, and of course explain ahead of time that they are going to do this and make sure others agree to and accept this before doing this type of thing.  Then while they are gone and not involving themselves others will notice a before-and-after difference and when whomever isn't credible or trusted comes back then they can say 'I told you so' and have credibility if what they were expecting happened.  This isn't foolproof and of course is risky as others have to make their own judgements and opinions and might still not trust someone who uses this technique who might still be suspected of being deceptive/dishonest/sneaky.  On the other hand if it works it really pays off.  This method and logic involved works with zarakite values and common sense thinking that I have and all zarakites and all sky boys of all types I would want have and is irregardless of face and individual personality.  No sky boys of any type or face at any age are mind readers of course so this type of method of proving trust and credibility as well as re-establishing it if suspected of being bad or hostile work.

Hypothetical #0004:
	2020-03-12  21:06  A boy who lives in a small suburban early-21st-century town is playing with a ball and accidentally throws or hits the ball through a next-door-neighbor's window.  The next-door neighbor is one his family doesn't know that well, but he knows which house it is and he knows it is his neighbor's house.  It is a weekday afternoon and his parents are not yet home and he thinks the neighbor is home.  According to zarakite values the boy first-of-all shouldn't wait but should simply knock on the door of the neighbor and apologize and explain the ball is his.  He should not have to have his parents standing behind him to make him apologize.  He should also not be scared or afraid to knock on the door to apologize.  Once his parents are home he should also tell his parents and expect his parents to talk to the neighbor, and he should expect for his parents or the neighbor to probably pay for the damage to the window right away, but long-term the boy should expect to save up money to pay for the damage done to the neighbor's window and anything inside the house etc.  If the boy's parents give their boy money or forgive some of his debt for him that's an act of love between the boy and his parents.  This hypothetical has zarakite values being enforced and used left and right throughout the entire hypothetical.  This includes the zarakite value that if you do someone wrong, you should try to make up for what you did to them, and their property and money is included.